EML 计算台 v1.1.0 发布包

解压后双击 eml-workbench.html 即可运行，无需安装依赖或启动服务器。
源码：https://github.com/xiaoxuhui/EML
许可证：MIT
