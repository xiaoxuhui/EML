EML 计算台 v1.0.0

使用方法：
1. 解压本发布包。
2. 双击 eml-workbench.html。
3. 使用现代版本的 Google Chrome、Microsoft Edge 或其他 Chromium 浏览器打开。

数据说明：
- 程序会把当前列表保存在浏览器本地缓存中。
- 请定期使用“保存列表”导出 JSON 备份。
- 更换浏览器或清理浏览器数据前应先保存列表。

版本能力和已知限制请参阅项目仓库中的 doc/阶段性总结-v1.0.0.md。
